import time
import os
import json
from . import ingame
'''import utils.funcs as funcs
import utils.error as error
import utils.database as database'''
from utils import funcs
from utils import error
from utils import database

# account defaults
'''lang = {'gb': 'en','jp': 'jp'}
country = {'gb': 'US', 'jp': 'JP'}
currency = {'gb': 'USD', 'jp': 'JPY'}'''
lang = 'en'
country = 'US'
currency = 'USD'
uuid = None
ad = None

# android User-Agent
device_name1 = 'SM'
device_model1 = 'SM-S10'
device_ver1 = '9.0'
device_agent1 = 'Dalvik/2.1.0 (Linux; Android 9.0; SM-S10)'
# ios User-Agent
device_name2 = 'iPhone'
device_model2 = 'iPhone XR'
device_ver2 = '13.0'
device_agent2 = 'CFNetwork/808.3 Darwin/16.3.0 (iPhone; CPU iPhone OS 13_0 like Mac OS X)'

# cached account config
loaded = None  # save file
account = ''  # identifier
acc_os = ''  # platform
acc_ver = ''  # game version
sess_token = ''  # session token
sess_secret = ''  # session secret

# client data
database_ts = str(int(round(time.time(), 0)))
asset_ts = None

file_ts1 = str(int(round(time.time(), 0)))
file_ts2 = str(int(round(time.time(), 0)))
db_ts1 = str(int(round(time.time(), 0)))
db_ts2 = str(int(round(time.time(), 0)))

# store account information
teams = []
support_leader = 0
cards = []
item_cards = []
events = {}
user = {}
selected_team = 0


def assign_tables():
    global loaded
    global cards
    global item_cards
    global user
    global support_leader
    global selected_team
    # exec_query(file, pw, query, table, where, amount)
    # database.exec_query(f"./data/gb.db", None, None,
    # database.exec_query(f"../saves/{loaded}.db", None, None
    cards = database.exec_query(f"../saves/{loaded}.db", None, None, 'cards', None, 1)
    item_cards = database.exec_query(f"../saves/{loaded}.db", None, None, 'item_cards', None, 1)
    '''teams = database.exec_query(f"../saves/{loaded}.db", None, None, 'teams', None, 1)'''
    user_db = database.exec_query(f"../saves/{loaded}.db", None, None, 'user', None, 0)
    user = json.loads(user_db[3])
    support_leader = int(user_db[1])
    selected_team = int(user_db[2])
    return True


'''def card_pool(card):
    global loaded
    query = database.exec_query(f"../saves/{loaded}.db", None, None, 'drops', 'unique_id=' + str(card), 0)
    if query is None:
        database.exec_change(f"../saves/{loaded}.db", None, f"INSERT INTO drops(unique_id, test) VALUES (?, ?)", (int(card), 0))'''


def remove_cards(input_cards, input_items):
    global loaded
    if input_cards is None:
        input_cards = []
    if input_items is None:
        input_items = []
    card_id = None
    for i in input_cards:
        if 'id' in i and i['id'] is not None:
            card_id = i['id']
        elif i is int:
            card_id = i
        query = database.exec_query(f"../saves/{loaded}.db", None, None, 'cards', 'id=' + str(card_id), 0)
        if query is not None:
            database.exec_change(f"../saves/{loaded}.db", None, "DELETE FROM cards WHERE id=?", (int(card_id),))
        '''query = database.exec_query(f"../saves/{loaded}.db", None, None, 'drops', 'unique_id=' + str(card_id), 0)
        if query is not None:
            database.exec_change(f"../saves/{loaded}.db", None, "DELETE FROM drops WHERE unique_id=?",
                                 (int(card_id),))'''
    for i in input_items:
        if 'card_id' in i and i['card_id'] is not None:
            query = database.exec_query(f"../saves/{loaded}.db", None, None, 'item_cards', 'card_id=' + str(i['card_id']), 0)
            if query is not None:
                if i['quantity'] != 0:
                    database.exec_change(f"../saves/{loaded}.db", None, "UPDATE item_cards SET quantity=? WHERE card_id=?", (int(query[1]) + int(i['quantity']), int(i['card_id'])))
                else:
                    database.exec_change(f"../saves/{loaded}.db", None, "DELETE FROM item_cards WHERE card_id=?", (int(i['card_id']),))
    assign_tables()


def add_cards(input_cards, input_items):
    global loaded
    if input_cards is None:
        input_cards = []
    if input_items is None:
        input_items = []
    for i in input_cards:
        query = database.exec_query(f"../saves/{loaded}.db", None, None, 'cards', 'id=' + str(i['id']), 0)
        if query is None:
            database.exec_change(f"../saves/{loaded}.db", None, f"INSERT INTO cards(id, card_id, updated_at, serialized) VALUES (?, ?, ?, ?)", (int(i['id']), int(i['card_id']), int(i['updated_at']), str(json.dumps(i))))
    for i in input_items:
        query = database.exec_query(f"../saves/{loaded}.db", None, None, 'item_cards', 'card_id=' + str(i['card_id']), 0)
        if query is None:
            if int(i['quantity']) != 0:
                database.exec_change(f"../saves/{loaded}.db", None, f"INSERT INTO item_cards(card_id, quantity) VALUES (?, ?)", (int(i['card_id']), int(i['quantity'])))
        else:
            update_cards(None, input_items)
    assign_tables()


def update_cards(input_cards, input_items, eza_drops=None):
    #print(input_items)
    global loaded
    if input_cards is None:
        input_cards = []
    if input_items is None:
        input_items = []
    for i in input_cards:
        query = database.exec_query(f"../saves/{loaded}.db", None, None, 'cards', 'id=' + str(i['id']), 0)
        if query is not None:
            database.exec_change(f"../saves/{loaded}.db", None, "UPDATE cards SET updated_at=?, serialized=? where id=?",
                          (int(i['updated_at']), str(json.dumps(i)), int(i['id'])))
    for i in input_items:
        query = database.exec_query(f"../saves/{loaded}.db", None, None, 'item_cards', 'card_id=' + str(i['card_id']), 0)
        if query is not None:
            if int(i['quantity']) != 0:
                if eza_drops:
                    database.exec_change(f"../saves/{loaded}.db", None, "UPDATE item_cards SET quantity=? where card_id=?", (int(i['quantity']), int(i['card_id'])))
                else:
                    database.exec_change(f"../saves/{loaded}.db", None, "UPDATE item_cards SET quantity=? where card_id=?", (int(query[1]) + int(i['quantity']), int(i['card_id'])))
            else:
                remove_cards(None, input_items)
    assign_tables()


def update_save(save=None, ver=None, os=None, iden=None, ad_id=None, uid=None):
    global ad
    global uuid
    #print(f"{save}-{ver}-{os}-{iden}-{ad_id}-{uid}")
    if save is not None:
        # name TEXT PRIMARY KEY, version TEXT, opsys TEXT, identifier TEXT, ad_id TEXT, uuid TEXT
        query = database.exec_query(f"../saves/{save}.db", None, None, 'account', 'save_length=' + str(len(save)), 0)
        if query is not None:
            if ver is None:
                ver = query[1]
            if os is None:
                os = query[2]
            if iden is None:
                iden = query[3]
            if ad_id is None:
                ad_id = query[4]
            if uid is None:
                uid = query[5]
            ad = ad_id
            uuid = uid
            database.exec_change(f"../saves/{save}.db", None, "UPDATE account SET version=?, opsys=?, identifier=?, ad_id=?, uuid=? where save_length=?", (ver, os, iden, ad_id, uid, len(save)))
        else:
            print('[!] Save does not exist!')
            exit()
    else:
        print('[!] No save name provided!')
        exit()


# update "/user" (account information)
def update_account(user_data=None, support=None, team=None):
    global support_leader
    global teams
    global user
    #unique_id INTEGER PRIMARY KEY, support INTEGER, selected_team INTEGER, serialized TEXT NOT NULL
    query = database.exec_query(f"../saves/{loaded}.db", None, None, 'user', 0, 1)
    if len(query) == 0:
        if user_data is not None:
            if 'user' in user_data:
                id = user_data['user']['id']
                user_data = str(json.dumps(user_data))
                user = json.loads(user_data)
        if support is not None:
            if 'support_leaders' in support:
                arr = support['support_leaders']
            else:
                arr = support
            if 'support_leader_ids' in arr:
                if len(arr['support_leader_ids']) != 0:
                    support = arr['support_leader_ids'][0]
                    support_leader = support
        teams = team
        if team is not None:
            if 'selected_team_num' in team:
                team = team['selected_team_num']
        database.exec_change(f"../saves/{loaded}.db", None, "INSERT INTO user(unique_id, support, selected_team, serialized) VALUES (?, ?, ?, ?)", (int(id), int(support), int(team), str(user_data)))
    else:
        query = query[0]
        id = query[0]
        user = json.loads(query[3])
        if user_data is not None:
            if 'user' in user_data:
                id = user_data['user']['id']
                user_data = str(json.dumps(user_data))
                user = json.loads(user_data)
        support_leader = query[1]
        if support is not None:
            if 'support_leaders' in support:
                arr = support['support_leaders']
            else:
                arr = support
            if 'support_leader_ids' in arr:
                if len(arr['support_leader_ids']) != 0:
                    support = arr['support_leader_ids'][0]
                    support_leader = support
        else:
            support = query[1]
        if team is not None:
            teams = team
            if 'selected_team_num' in team:
                team = team['selected_team_num']
            else:
                team = query[2]
        else:
            team = query[2]
        database.exec_change(f"../saves/{loaded}.db", None, "UPDATE user SET support=?, selected_team=?, serialized=? where unique_id=?", (int(support), int(team), str(user_data), int(id)))
    return True


# update database, assets, caches.
def load_account(save, iden, par_ver, par_os, token, secret, show=False):
    global loaded
    global account
    global acc_ver
    global acc_os
    global sess_token
    global sess_secret
    global events
    loaded, account, acc_ver, acc_os, sess_token, sess_secret = save.replace('.db', ''), iden, par_ver, par_os, token, secret
    if funcs.check_database(acc_ver, acc_os, sess_token, sess_secret):
        funcs.check_asset()
        # login > user > cards > resources
        info = ingame.user(acc_ver, acc_os, sess_token, sess_secret, False)
        box = {}
        query = database.exec_query(f"../saves/{loaded}.db", None, None, 'cards', 0, 1)
        if len(query) == 0:
            box = ingame.cards(acc_ver, acc_os, sess_token, sess_secret)
        store = ingame.login_resources(acc_ver, acc_os, sess_token, sess_secret, str(int(round(time.time(), 0))))
        update_account(info, store, store['teams'])
        if 'cards' in box:
            add_cards(box['cards'], None)
        if 'item_cards' in box:
            add_cards(None, box['item_cards'])
        assign_tables()
        store = ingame.events(acc_ver, acc_os, sess_token, sess_secret)
        if 'error' not in store:
            events = store
        else:
            error.handler('errLS1', store)
        if show:
            funcs.navigator(99)
    else:
        loaded = None


def update_events():
    global acc_ver
    global acc_os
    global sess_token
    global sess_secret
    global events
    store = ingame.events(acc_ver, acc_os, sess_token, sess_secret)
    if 'error' not in store:
        events = store
    else:
        error.handler('errorLS2', store)
