import requests
import json
import os as fs
import re
from datetime import datetime
from colorama import init, Fore
init(autoreset=True)

import config
from . import crypto
from . import error
from . import database
from . import colors
from api import auth
from api import outgame
from api import caches

failed_refreshes = 0


def save_settings(data):
    f = open('../settings-2.0.9.json', 'w')
    f.write(json.dumps(data))
    f.close()
    return True


def get_settings():
    f = open('../settings-2.0.9.json', 'r')
    txt = f
    settings = json.load(txt)
    f.close()
    return settings


def subfolders():
    if not fs.path.isdir('../saves'):
        try:
            fs.mkdir('../saves')  # outside source
            print('"saves" directory created.')
        except:
            print('unable to create "saves" directory.')
    if not fs.path.isdir('../summaries'):
        try:
            fs.mkdir('../summaries')  # outside source
        except:
            print('unable to create "summaries" directory.')
    if not fs.path.isdir('./data'):
        try:
            fs.mkdir('./data')  # inside source
        except:
            print('unable to create "data" directory.')
    if not fs.path.isdir('../custom_commands'):
        try:
            fs.mkdir('../custom_commands')  # inside source
        except:
            print('unable to create "custom_commands" directory.')
    if fs.path.isfile('../settings-2.0.7.json'):
        fs.unlink('../settings-2.0.7.json')
    if not fs.path.isfile('../settings-2.0.9.json'):
        settings = {
            'stam_use_stone': True,
            'team_builder': False,
            'capacity': True,
            'display_drops': True,
            'display_ids': True,
            'display_only_ids': False,
            'display_stage_names': True,
            'drop_bonus': False,
            'potential_node': False,
            'stam_use_item': False,
            'display_claimed_gifts': False,
            'display_claimed_missions': False,
            'display_drop_names': True,
            'stack_drops': True,
            'drops_boost': False,
            'animations': False,
            'use_keys': False,
            'hourglass': False,
            'baba_useless': False,
            'autosell': True,
            'summon_sell': False,
            'dev_mode': False,
            'linkups': False,
            'summongift': False,
            'colors': {
                'command': 'yellow',
                'description': 'green',
                'error': 'red',
                'success': 'green',
                'message': 'yellow',
                'drops': 'cyan'
            }
        }
        save_settings(settings)


def check_servers(ver):
    try:
        if ver == 'gb':
            url = config.gb_url + '/ping'
            code = config.gb_code['android']
        else:
            url = config.jp_url + '/ping'
            code = config.jp_code['android']
        headers = {
            'X-Platform': 'android',
            'X-ClientVersion': code,
            'X-Language': 'en',
            'X-UserID': '////'
        }
        r = requests.get(url, data=None, headers=headers)
        store = r.json()
        if 'error' not in store:
            if 'ping_info' in store:
                url = store['ping_info']['host']
                port = store['ping_info']['port_str']
                if ver == 'gb':
                    config.gb_url = 'https://' + str(url)
                    config.gb_port = str(port)
                else:
                    config.jp_url = 'https://' + str(url)
                    config.jp_port = str(port)
                return True
            else:
                print(colors.render('{error}[' + ver + ' server] can\'t connect.'))
        else:
            if 'title' in store['error']:
                if 'description' in store['error'] and store['error']['description'] != '':
                    desc = str(store['error']['description']) + '\n' + str(store['error']['code'])
                else:
                    desc = str(store['error']['code'])
                if 'until' in store['error'] and store['error']['until'] != '':
                    ends_at = '\nEnds: ' + datetime.utcfromtimestamp(int(store['error']['until'])).strftime('%m/%d/%Y %H:%M.%S')
                else:
                    ends_at = ''
                print(colors.render('{error}[' + str(ver).upper() + '] ' + store['error']['title'] + '\n' + desc + ends_at))
                if ver == 'gb':
                    config.gb_maint = True
                else:
                    config.jp_maint = True
            else:
                print(colors.render('{error}[' + ver + ' server] can\'t connect.'))
            return True
    except:
        print(colors.render('{error}[' + ver + ' server] can\'t connect.'))
        return False


def navigator(page):
    if int(page) == 7:
        for i in fs.listdir('../custom_commands/'):
            print(colors.render('{command}' + i.replace('.txt', '')))
    else:
        f = open(f"./farming/navi/{page}", 'r')
        txt = f.read().replace('{CYAN}', Fore.CYAN).replace('{LTYELLOW}', Fore.LIGHTYELLOW_EX).replace('{GREEN}',
                                                                                                       Fore.LIGHTGREEN_EX).replace(
            '{YELLOW}', Fore.YELLOW).replace('{RED}', Fore.LIGHTRED_EX).replace('{BLUE}', Fore.BLUE).replace('{PURPLE}',
                                                                                                             Fore.LIGHTMAGENTA_EX).replace(
            '\\n', '\n')
        for match in re.findall(r'\\x[0-9A-Fa-f]{2}', txt):
            txt = txt.replace(match, chr(int(match[2:], 16)))
        f.close()
        print(colors.render(txt))


def check_database(ver, os, token, secret):
    print(colors.render('{message}[!] checking for new database...'))
    store = outgame.getDatabase(ver, os, token, secret)
    if 'error' not in store:
        version = store['version']
        caches.database_ts = str(version)
        if fs.path.isfile('./data/' + caches.acc_ver + '-data.txt'):
            f = open('./data/' + caches.acc_ver + '-data.txt', 'r')
            ver2 = f.readline().rstrip()
            f.close()
            if str(ver2) != str(version):
                print(str(version))
                fs.unlink('./data/' + caches.acc_ver + '-data.txt')
                database.download(ver, os, token, secret, version, store['url'])
        else:
            print(str(version))
            database.download(ver, os, token, secret, version, store['url'])
        return True
    else:
        error.handler('DB DL', store)
        return False


def check_asset():
    print(colors.render('{message}[!] checking for new asset(s)...'))
    if fs.path.isfile('./data/' + caches.acc_ver + '-dl.txt'):
        f = open('./data/' + caches.acc_ver + '-dl.txt', 'r')
        ver2 = f.readline().rstrip()
        f.close()
        store = outgame.getAsset(caches.acc_ver, caches.acc_os, caches.sess_token, caches.sess_secret, ver2)
        if 'error' not in store:
            version = store['latest_version']
            if str(ver2) != str(version):
                print(str(version))
                fs.unlink('./data/' + caches.acc_ver + '-dl.txt')
                f = open('./data/' + caches.acc_ver + '-dl.txt', 'w')
                f.write(str(version) + '\n')
                f.close()
                caches.asset_ts = str(version)
            else:
                caches.asset_ts = str(version)
        else:
            error.handler('checkAsset', store)
    else:
        store = outgame.getAsset(caches.acc_ver, caches.acc_os, caches.sess_token, caches.sess_secret)
        if 'error' not in store:
            version = store['latest_version']
            print(str(version))
            f = open('./data/' + caches.acc_ver + '-dl.txt', 'w')
            f.write(str(version) + '\n')
            f.close()
            caches.asset_ts = str(version)
        else:
            error.handler('checkAsset', store)


def create_save_file(acc_ver, acc_os):
    print(colors.render('{success}What would you like to name this save?'))
    save = input().lower()
    if len(str(save)) >= 1:
        if fs.path.isfile('../saves/' + str(save) + '.db'):
            print(colors.render('{error}save name already exists!'))
            create_save_file(acc_ver, acc_os)
        else:
            if ' ' not in save and '\n' not in save and '\r' not in save:
                if str(save).isalnum():
                    open(f"../saves/{save}.db", 'w')
                    database.exec_change(f"../saves/{save}.db", None,
                                         "CREATE TABLE account(save_length INTEGER PRIMARY KEY, version TEXT, opsys TEXT, identifier TEXT, ad_id TEXT, uuid TEXT)")
                    database.exec_change(f"../saves/{save}.db", None,
                                         "CREATE TABLE user(unique_id INTEGER PRIMARY KEY, support INTEGER, selected_team INTEGER, serialized TEXT NOT NULL)")
                    database.exec_change(f"../saves/{save}.db", None,
                                         "CREATE TABLE cards(id INTEGER PRIMARY KEY, card_id INTEGER, updated_at INTEGER, serialized TEXT NOT NULL)")
                    database.exec_change(f"../saves/{save}.db", None,
                                         "CREATE TABLE item_cards(card_id INTEGER PRIMARY KEY, quantity INTEGER)")
                    '''database.exec_change(f"../saves/{save}.db", None,
                                         "CREATE TABLE drops(unique_id INTEGER PRIMARY KEY, test INTEGER)")
                    database.exec_change(f"../saves/{save}.db", None,
                                         "CREATE TABLE friends(unique_id INTEGER PRIMARY KEY, serialized TEXT NOT NULL)")
                    database.exec_change(f"../saves/{save}.db", None,
                                         "CREATE TABLE teams(num INTEGER PRIMARY KEY, team TEXT NOT NULL)")'''
                    database.exec_change(f"../saves/{save}.db", None,
                                         f"INSERT INTO account (save_length, version, opsys, identifier, ad_id, uuid) VALUES (?, ?, ?, ?, ?, ?)", (str(len(save)), str(acc_ver), str(acc_os), '', '', ''))
                    print(colors.render('{success}saved account as "saves/' + str(save) + '.db"\nuse "load ' + str(save) + '" to log-in anytime.'))
                    return save
                else:
                    print(colors.render('{error}save name must not contain symbols!'))
                    create_save_file(acc_ver, acc_os)
            else:
                print(colors.render('{error}save name must not contain spaces!'))
                create_save_file(acc_ver, acc_os)
    else:
        print(colors.render('{error}save name is too small!'))
        create_save_file(acc_ver, acc_os)


def refresh():
    global failed_refreshes
    if failed_refreshes > 0:
        print(colors.render('{error}[!] cannot refresh session!\ncheck your connection or PC clock.'))
        exit()
    else:
        store = auth.login(caches.acc_ver, caches.acc_os, caches.loaded, crypto.basic(caches.account), False)
        if 'error' not in store:
            caches.sess_token, caches.sess_secret = store['access_token'], store['secret']
            print(colors.render('{success}session renewed.'))
        else:
            error.handler('refresh', store)
            failed_refreshes = failed_refreshes + 1


def render_card_text(card, is_drop, add_rarity, all_info, is_friend=False):
    settings = get_settings()
    '''
    rarity changed from 6 to 5
    elemental changed from 13 to 12
    leader skill changed from 24 to 22
    max sa changed from 15 to 14
    max lvl changed from 14 to 13
    team cost changed from 5 to 4
    potential board changed from 54 to 52

    TODO get closest lvl to EXP value
    database.fetch(caches.acc_ver + '.db', 'card_exps', 'exp_total=' + str(i['exp'])))[1]
    '''
    card_quantity = ''
    id_toggle = ''
    if is_drop:
        if 'item_id' in card:
            card_id = str(card['item_id'])
        else:
            card_id = str(card['card_id'])
        if 'quantity' in card:
            card_quantity = 'x' + str(card['quantity'])
        else:
            card_quantity = ''
    elif is_friend:
        card = card['user']['leader']
        card_id = str(card['card_id'])
    else:
        card_id = str(card['card_id'])
    if settings['display_ids']:
        id_toggle = ' (' + card_id + ')'
    element = '?'
    db_ele = database.exec_query(f"./data/gb.db", None, None, 'cards', 'id=' + card_id, 0)[12]
    if db_ele is 0 or db_ele is 10 or db_ele is 20:
        element = Fore.CYAN + 'AGL'
    if db_ele is 1 or db_ele is 11 or db_ele is 21:
        element = Fore.GREEN + 'TEQ'
    if db_ele is 2 or db_ele is 12 or db_ele is 22:
        element = Fore.MAGENTA + 'INT'
    if db_ele is 3 or db_ele is 13 or db_ele is 23:
        element = Fore.RED + 'STR'
    if db_ele is 4 or db_ele is 14 or db_ele is 24:
        element = Fore.YELLOW + 'PHY'
    if add_rarity:
        if database.exec_query(f"./data/gb.db", None, None, 'cards', 'id=' + card_id, 0)[5] is 0:
            rarity = 'N'
        if database.exec_query(f"./data/gb.db", None, None, 'cards', 'id=' + card_id, 0)[5] is 1:
            rarity = 'R'
        if database.exec_query(f"./data/gb.db", None, None, 'cards', 'id=' + card_id, 0)[5] is 2:
            rarity = 'SR'
        if database.exec_query(f"./data/gb.db", None, None, 'cards', 'id=' + card_id, 0)[5] is 3:
            rarity = 'SSR'
        if database.exec_query(f"./data/gb.db", None, None, 'cards', 'id=' + card_id, 0)[5] is 4:
            rarity = 'UR'
        if database.exec_query(f"./data/gb.db", None, None, 'cards', 'id=' + card_id, 0)[5] is 5:
            rarity = 'LR'
        element = element + ' ' + rarity
    if all_info:
        card = element + ' ' + database.exec_query(f"./data/gb.db", None, None, 'cards', 'id=' + str(card['card_id']), 0)[
            1] + ' [' + database.exec_query(f"./data/gb.db", None, None, 'leader_skills', 'id=' + str(
            database.exec_query(f"./data/gb.db", None, None, 'cards', 'id=' + str(card['card_id']), 0)[22]), 0)[
            1] + '] (' + str(card['card_id']) + ')\n' + Fore.LIGHTWHITE_EX + 'SA: ' + str(card['skill_lv']) + '/' + str(
            database.exec_query(f"./data/gb.db", None, None, 'cards', 'id=' + str(card['card_id']), 0)[
                14]) + ', Potential: ' + str(card['released_rate']) + '%, Lvl: ?/' + str(
            database.exec_query(f"./data/gb.db", None, None, 'cards', 'id=' + str(card['card_id']), 0)[
                13]) + ', Cost: ' + str(
            database.exec_query(f"./data/gb.db", None, None, 'cards', 'id=' + str(card['card_id']), 0)[
                4]) + ', uid: ' + str(card['id'])
    else:
        card = element + ' ' + database.exec_query(f"./data/gb.db", None, None, 'cards', 'id=' + card_id, 0)[
            1] + ' [' + database.exec_query(f"./data/gb.db", None, None, 'leader_skills', 'id=' + str(
            database.exec_query(f"./data/gb.db", None, None, 'cards', 'id=' + card_id, 0)[22]), 0)[
                   1] + '] ' + card_quantity + id_toggle
    return card


def convert_save(save, type):
    # save file
    if type == 0:
        save_file = open('../saves/' + str(save), 'r')
        contents = save_file.read().split('\n')
        save_file.close()
        # 16v1
        if len(contents) == 2 or len(contents) == 3:
            fs.replace(f"../saves/{save}", f"../saves/old_saves/{save}")
            print(colors.render('{error}[!] Converting save: "' + str(save) + '" into a database; please name it.'))
            save = create_save_file(str(contents[0].split(':')[0]), str(contents[0].split(':')[1]))
            caches.update_save(save=save, ver=None, os=None, iden=str(contents[1]), ad_id='95c27e08-72bb-4760-83e8-9e878d1999f8', uid='0f97df48-01e3-4d8f-8ba0-a1e8cced278c:5bf18553fe25d277')
        # flashchaser/karysbot/botzone/ethansbot
        if len(contents) >= 4:
            iden = contents[0]
            if len(str(iden).rstrip()) >= 100:
                # flashv1 and botzone is missing the ad_id...
                if contents[1] != 'None' and contents[1] != '':
                    ad_id = contents[1]
                else:
                    ad_id = '95c27e08-72bb-4760-83e8-9e878d1999f8'
                if contents[2] != 'None' and contents[1] != '':
                    uuid = contents[2]
                else:
                    uuid = '0f97df48-01e3-4d8f-8ba0-a1e8cced278c:5bf18553fe25d277'
                acc_os = str(contents[3]).lower()
                if contents[4] != '':
                    if str(contents[4]).lower() == 'global':
                        acc_ver = 'gb'
                    elif str(contents[4]).lower() == 'japan':
                        acc_ver = 'jp'
                else:
                    print(colors.render('{error}[!] Flashchaser save ("' + str(save) + '") is too old!\n{message}Please select the game version... (gb/jp)'))
                    acc_ver = input()
                fs.replace(f"../saves/{save}", f"../saves/old_saves/{save}")
                print(colors.render('{error}[!] Converting save: "' + str(save) + '" into a database; please name it.'))
                save = create_save_file(acc_ver, acc_os)
                caches.update_save(save=save, ver=None, os=None, iden=str(iden), ad_id=ad_id, uid=uuid)
            else:
                print(colors.render('{error}[!] unknown save format. "' + str(save) + '"'))
        print('')
    # save database
    if type == 1:
        # bladefive
        if 'saves' in save:
            # name - iden - uuid - ver
            query = database.exec_query(f"../saves/{save}.db", None, None, 'android', 0, 1)
            if query is not None:
                for i in query:
                    if str(i[3]).lower() == 'global':
                        acc_ver = 'gb'
                    elif str(i[3]).lower() == 'japan':
                        acc_ver = 'jp'
                    ad_id = '95c27e08-72bb-4760-83e8-9e878d1999f8'
                    if i[2] is not None and str(i[2]) != '':
                        uuid = str(i[2])
                    else:
                        uuid = '0f97df48-01e3-4d8f-8ba0-a1e8cced278c:5bf18553fe25d277'
                    fs.replace(f"../saves/{save}", f"../saves/old_saves/{save}")
                    print(colors.render('{error}[!] Converting save: "' + str(i[0]) + '" into a database; please name it.'))
                    save = create_save_file(acc_ver, 'android')
                    caches.update_save(save=save, ver=None, os=None, iden=str(i[1]), ad_id=ad_id, uid=uuid)
                    print('')
            else:
                print(colors.render('{error}[!] No saves in Bladefive - Android.'))
            query = database.exec_query(f"../saves/{save}.db", None, None, 'ios', 0, 1)
            if query is not None:
                for i in query:
                    if str(i[3]).lower() == 'global':
                        acc_ver = 'gb'
                    elif str(i[3]).lower() == 'japan':
                        acc_ver = 'jp'
                    ad_id = '95c27e08-72bb-4760-83e8-9e878d1999f8'
                    if i[2] is not None and str(i[2]) != '':
                        uuid = str(i[2])
                    else:
                        uuid = '0f97df48-01e3-4d8f-8ba0-a1e8cced278c:5bf18553fe25d277'
                    fs.replace(f"../saves/{save}", f"../saves/old_saves/{save}")
                    print(colors.render('{error}[!] Converting save: "' + str(i[0]) + '" into a database; please name it.'))
                    save = create_save_file(acc_ver, 'ios')
                    caches.update_save(save=save, ver=None, os=None, iden=str(i[1]), ad_id=ad_id, uid=uuid)
                    print('')
            else:
                print(colors.render('{error}[!] No saves in Bladefive - iOS.'))
